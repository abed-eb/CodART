from gen.java9 import Java9_v2Listener


class MoveClassRefactoringListener(Java9_v2Listener):
    pass

