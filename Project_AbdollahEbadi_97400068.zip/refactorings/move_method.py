from gen.java9 import Java9_v2Listener


class MoveMethodRefactoringListener(Java9_v2Listener):
    pass

